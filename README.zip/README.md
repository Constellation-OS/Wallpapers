# Wallpapers
Constellation's Wallpapers Repository!
Please note, We do not own most of these wallpapers, If you'd like an image removed, please open up a Github issue above, and we'll sort it.

Also, if you wish to add a wallpaper, add it to \Other, with a Pull Request, and we'll take a look.
